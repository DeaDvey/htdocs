#   	  : .
from datetime import datetime
import time
nums=[" ","⡀","⠄","⡄","⠂","⡂","⠆","⡆","⠁","⡁","⠅","⡅","⠃","⡃","⠇","⡇"]

hour1 = int(datetime.now().strftime("%H")[0])
hour2 = int(datetime.now().strftime("%H")[1])
min1  = int(datetime.now().strftime("%M")[0])
min2  = int(datetime.now().strftime("%M")[1])
sec1  = int(datetime.now().strftime("%S")[0])
sec2  = int(datetime.now().strftime("%S")[1])


print(nums[hour1],nums[hour2],nums[min1],nums[min2],nums[sec1],nums[sec2],sep="")
