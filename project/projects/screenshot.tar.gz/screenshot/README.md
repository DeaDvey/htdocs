# screenshot
Screenshot a region of the screen and copy as welll as save it to a folder

run the install script (you may need to ```chmod +x install.sh``` it)
